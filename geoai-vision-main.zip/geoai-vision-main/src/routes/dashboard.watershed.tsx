import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/dashboard/TopBar";
import { useState, useRef, MouseEvent } from "react";
import { ChevronRight, Layers, Eye, EyeOff, Download, Maximize2 } from "lucide-react";
import wsOriginal from "@/assets/watershed-original.jpg";
import wsMask from "@/assets/watershed-mask.jpg";

export const Route = createFileRoute("/dashboard/watershed")({
  component: Watershed,
});

function Watershed() {
  const [pos, setPos] = useState(50);
  const ref = useRef<HTMLDivElement>(null);
  const drag = useRef(false);
  const [layers, setLayers] = useState({ original: true, mask: true, terrain: false, rivers: true });
  const [active, setActive] = useState(0);

  const update = (x: number) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    setPos(Math.max(0, Math.min(100, ((x - r.left) / r.width) * 100)));
  };

  const tiles = [
    { id: "S2A_T43QFV", area: 1284, conf: 0.96, region: "Brahmaputra" },
    { id: "S2A_T44QFA", area: 842, conf: 0.94, region: "Subansiri" },
    { id: "L9_P137R042", area: 567, conf: 0.93, region: "Lohit" },
    { id: "S2B_T44RKR", area: 491, conf: 0.91, region: "Dibang" },
  ];

  return (
    <>
      <TopBar title="Watershed Studio" subtitle="Interactive segmentation viewer" />
      <div className="flex-1 p-4 md:p-6 grid grid-cols-1 xl:grid-cols-12 gap-4">
        <div className="xl:col-span-3 space-y-4">
          <div className="glass-strong glow-border rounded-3xl p-4">
            <div className="text-[10px] uppercase tracking-[0.2em] text-primary mb-3">Tile Library</div>
            <div className="space-y-2">
              {tiles.map((t, i) => (
                <button
                  key={t.id}
                  onClick={() => setActive(i)}
                  className={`w-full text-left p-3 rounded-xl transition ${active === i ? "bg-gradient-to-r from-primary/15 to-violet/10 border border-primary/30" : "glass hover:bg-white/[0.05]"}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs text-primary">{t.id}</span>
                    <ChevronRight className="h-3 w-3 text-muted-foreground" />
                  </div>
                  <div className="mt-1 text-sm font-medium">{t.region}</div>
                  <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
                    <span>{t.area} km²</span><span className="text-cyan">conf {t.conf}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="glass-strong glow-border rounded-3xl p-4">
            <div className="text-[10px] uppercase tracking-[0.2em] text-primary mb-3">Layer Controls</div>
            <div className="space-y-1.5">
              {Object.entries(layers).map(([k, v]) => (
                <button
                  key={k}
                  onClick={() => setLayers((s) => ({ ...s, [k]: !v }))}
                  className="flex items-center justify-between w-full p-2.5 rounded-lg hover:bg-white/[0.05] text-sm capitalize"
                >
                  <span className="flex items-center gap-2">
                    <Layers className="h-3.5 w-3.5 text-muted-foreground" />{k}
                  </span>
                  {v ? <Eye className="h-3.5 w-3.5 text-primary" /> : <EyeOff className="h-3.5 w-3.5 text-muted-foreground" />}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="xl:col-span-9 space-y-4">
          <div className="glass-strong glow-border rounded-3xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-primary">Active</div>
                <h3 className="font-display text-xl font-semibold">{tiles[active].region} · {tiles[active].id}</h3>
              </div>
              <div className="flex gap-2">
                <button className="glass rounded-xl p-2 hover:text-primary"><Maximize2 className="h-4 w-4" /></button>
                <button className="rounded-xl bg-gradient-to-r from-primary to-violet px-4 py-2 text-xs font-semibold text-primary-foreground glow-primary inline-flex items-center gap-1.5">
                  <Download className="h-3.5 w-3.5" /> Export Mask
                </button>
              </div>
            </div>

            <div
              ref={ref}
              onMouseDown={(e: MouseEvent) => { drag.current = true; update(e.clientX); }}
              onMouseUp={() => (drag.current = false)}
              onMouseLeave={() => (drag.current = false)}
              onMouseMove={(e: MouseEvent) => drag.current && update(e.clientX)}
              className="relative aspect-[16/10] rounded-2xl overflow-hidden cursor-ew-resize glow-border"
            >
              {layers.original && <img src={wsOriginal} alt="orig" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover" />}
              {layers.mask && (
                <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
                  <img src={wsMask} alt="mask" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover" />
                </div>
              )}
              {layers.terrain && <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,oklch(0.78_0.16_75/0.4),transparent_60%)]" />}
              <div className="absolute top-0 bottom-0 z-10" style={{ left: `${pos}%`, transform: "translateX(-50%)" }}>
                <div className="h-full w-0.5 bg-gradient-to-b from-primary via-cyan to-violet glow-primary" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-12 w-12 rounded-full glass-strong flex items-center justify-center glow-primary">
                  <ChevronRight className="h-4 w-4 -ml-1.5" />
                  <ChevronRight className="h-4 w-4 -ml-2 rotate-180" />
                </div>
              </div>
              <div className="absolute top-3 left-3 glass rounded-full px-3 py-1 text-[10px] uppercase tracking-widest">Original</div>
              <div className="absolute top-3 right-3 glass rounded-full px-3 py-1 text-[10px] uppercase tracking-widest text-cyan">Attention U-Net</div>
            </div>

            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { l: "Surface Area", v: `${tiles[active].area} km²` },
                { l: "Confidence", v: tiles[active].conf },
                { l: "Pixels", v: "1.24M" },
                { l: "Resolution", v: "10m / px" },
              ].map((s) => (
                <div key={s.l} className="glass rounded-xl p-3">
                  <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{s.l}</div>
                  <div className="mt-1 font-display text-xl font-bold text-gradient-cyan">{s.v}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { t: "Drainage Density", v: "0.84 km/km²" },
              { t: "Stream Order", v: "Strahler 6" },
              { t: "Catchment Length", v: "412 km" },
            ].map((m) => (
              <div key={m.t} className="glass-strong glow-border rounded-2xl p-5">
                <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{m.t}</div>
                <div className="mt-2 font-display text-2xl font-bold">{m.v}</div>
                <div className="mt-3 h-1 rounded-full bg-white/5">
                  <div className="h-full w-2/3 rounded-full bg-gradient-to-r from-primary to-violet" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

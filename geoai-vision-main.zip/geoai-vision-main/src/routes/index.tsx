import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState, useRef, MouseEvent } from "react";
import {
  ArrowRight, Satellite, Brain, Waves, Map as MapIcon, BarChart3,
  Upload, Sparkles, ChevronRight, Activity, Globe, Zap,
} from "lucide-react";
import earthHero from "@/assets/earth-hero.jpg";
import wsOriginal from "@/assets/watershed-original.jpg";
import wsMask from "@/assets/watershed-mask.jpg";
import { MeshBackground } from "@/components/MeshBackground";
import { Particles } from "@/components/Particles";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HYDRA·AI — Satellite Watershed Extraction with Attention U-Net" },
      { name: "description", content: "A NASA-grade AI geospatial platform for satellite-based watershed extraction, segmentation, and climate intelligence powered by Attention U-Net." },
      { property: "og:title", content: "HYDRA·AI — Geospatial AI for Watershed Intelligence" },
      { property: "og:description", content: "Real-time satellite watershed extraction, AI segmentation, and analytics for climate intelligence." },
    ],
  }),
  component: Landing,
});

const stats = [
  { label: "Mean IoU", value: "94.7%", icon: Brain },
  { label: "Watersheds Mapped", value: "12.4K", icon: Waves },
  { label: "Satellite Tiles", value: "2.1M", icon: Satellite },
  { label: "Inference Latency", value: "1.8s", icon: Zap },
];

const workflow = [
  { title: "Satellite Upload", desc: "Multi-spectral tiles ingested at scale", icon: Upload },
  { title: "Preprocessing", desc: "Atmospheric correction & normalization", icon: Sparkles },
  { title: "Attention U-Net", desc: "Gated attention inference on GPU", icon: Brain },
  { title: "Watershed Extraction", desc: "Hierarchical basin delineation", icon: Waves },
  { title: "GIS Mapping", desc: "Vector tiles, layers & overlays", icon: MapIcon },
  { title: "Analytics", desc: "Live dashboards & reports", icon: BarChart3 },
];

const features = [
  { title: "Attention U-Net Segmentation", desc: "Gated skip connections focus the network on hydrologically relevant regions for state-of-the-art accuracy.", icon: Brain, color: "from-primary/20 to-cyan/10" },
  { title: "Real-Time GIS Layers", desc: "Stream watershed masks, river boundaries, and terrain heatmaps over interactive map tiles.", icon: MapIcon, color: "from-violet/20 to-primary/10" },
  { title: "Climate Intelligence", desc: "Forecast flood risk and seasonal runoff with explainable AI confidence trends.", icon: Activity, color: "from-success/20 to-cyan/10" },
  { title: "Multi-Spectral Pipelines", desc: "Sentinel-2, Landsat-9, MODIS — orchestrated through a single command center.", icon: Satellite, color: "from-warning/20 to-primary/10" },
  { title: "Edge-to-Cloud Inference", desc: "From orbital downlink to your dashboard in under two seconds per tile.", icon: Zap, color: "from-violet/20 to-cyan/10" },
  { title: "Global Watershed Atlas", desc: "Curated reference basins with community-validated annotations.", icon: Globe, color: "from-primary/20 to-violet/10" },
];

function Landing() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <MeshBackground />
      <Nav />
      <Hero />
      <StatsBand />
      <Comparison />
      <Workflow />
      <Features />
      <CTA />
      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="sticky top-0 z-50 w-full">
      <div className="mx-auto mt-4 flex max-w-7xl items-center justify-between glass-strong rounded-2xl px-5 py-3 mx-4 lg:mx-auto">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-violet glow-primary">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          <div className="leading-tight">
            <div className="font-display font-bold text-sm tracking-tight">HYDRA·AI</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Geospatial OS</div>
          </div>
        </Link>
        <nav className="hidden md:flex items-center gap-7 text-sm text-muted-foreground">
          <a href="#features" className="hover:text-foreground transition-colors">Platform</a>
          <a href="#workflow" className="hover:text-foreground transition-colors">Workflow</a>
          <a href="#compare" className="hover:text-foreground transition-colors">Model</a>
          <Link to="/dashboard" className="hover:text-foreground transition-colors">Dashboard</Link>
        </nav>
        <Link
          to="/dashboard"
          className="group inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-primary to-violet px-4 py-2 text-xs font-semibold text-primary-foreground glow-primary hover:scale-[1.03] transition-transform"
        >
          Launch Console
          <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
        </Link>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative px-4 pt-20 pb-32 lg:pt-32">
      <Particles count={50} />
      <div className="mx-auto max-w-7xl grid lg:grid-cols-12 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="lg:col-span-6 relative z-10"
        >
          <div className="inline-flex items-center gap-2 glass rounded-full px-3 py-1.5 text-[11px]">
            <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse-glow" />
            <span className="uppercase tracking-[0.2em] text-muted-foreground">Live · v4.2 · Attention U-Net</span>
          </div>
          <h1 className="mt-6 font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.02] tracking-tighter">
            Mapping Earth's <span className="text-gradient">water</span> with neural precision.
          </h1>
          <p className="mt-6 text-base sm:text-lg text-muted-foreground max-w-xl leading-relaxed">
            HYDRA·AI fuses orbital imagery with Attention U-Net inference to extract watersheds,
            forecast floods, and stream a NASA-grade geospatial command center to your browser.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              to="/dashboard"
              className="group inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-primary to-violet px-6 py-3.5 text-sm font-semibold text-primary-foreground glow-primary hover:scale-[1.02] transition-transform"
            >
              Open Command Center
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <a
              href="#workflow"
              className="inline-flex items-center gap-2 rounded-2xl glass px-6 py-3.5 text-sm font-semibold hover:bg-white/[0.06] transition"
            >
              View Workflow <ChevronRight className="h-4 w-4" />
            </a>
          </div>
          <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            <span>Sentinel-2 · Landsat-9 · MODIS</span>
            <span>· ISO 19115</span>
            <span>· OGC WMS</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="lg:col-span-6 relative"
        >
          <div className="relative aspect-square max-w-[640px] mx-auto">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/30 to-violet/20 blur-3xl" />
            <div className="absolute inset-0 animate-spin-slow">
              <div className="absolute inset-4 rounded-full border border-primary/30" />
              <div className="absolute inset-12 rounded-full border border-dashed border-primary/20" />
            </div>
            <img
              src={earthHero}
              alt="AI segmentation overlay on Earth from satellite"
              width={1600}
              height={1600}
              className="relative z-10 h-full w-full object-cover rounded-full glow-primary"
            />
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute -left-2 top-12 z-20 glass-strong rounded-2xl p-3 w-44"
            >
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Inference</div>
              <div className="font-display text-xl font-bold text-gradient-cyan">94.7% IoU</div>
              <div className="mt-2 h-1 rounded-full bg-white/5">
                <div className="h-full w-[94%] rounded-full bg-gradient-to-r from-primary to-cyan" />
              </div>
            </motion.div>
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 5, repeat: Infinity, delay: 1 }}
              className="absolute -right-2 bottom-16 z-20 glass-strong rounded-2xl p-3 w-48"
            >
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground">
                <Satellite className="h-3 w-3" /> Tile · S2A_T43QFV
              </div>
              <div className="mt-1 font-display text-lg font-bold">Watershed · 1,284 km²</div>
              <div className="text-[10px] text-muted-foreground">Confidence 0.96</div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function StatsBand() {
  return (
    <section className="relative px-4 pb-20">
      <div className="mx-auto max-w-7xl grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
            className="glass-strong glow-border rounded-2xl p-5 hover:bg-white/[0.05] transition group"
          >
            <s.icon className="h-4 w-4 text-primary mb-3 group-hover:scale-110 transition" />
            <div className="font-display text-3xl font-bold tracking-tight">{s.value}</div>
            <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mt-1">{s.label}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function Comparison() {
  const [pos, setPos] = useState(50);
  const ref = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const update = (clientX: number) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const p = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.max(0, Math.min(100, p)));
  };

  return (
    <section id="compare" className="relative px-4 py-20">
      <div className="mx-auto max-w-7xl">
        <SectionTitle eyebrow="Attention U-Net" title="Before & after segmentation" subtitle="Drag to reveal the AI-extracted watershed mask layered atop the original satellite tile." />
        <div
          ref={ref}
          onMouseMove={(e: MouseEvent) => dragging.current && update(e.clientX)}
          onMouseDown={(e) => { dragging.current = true; update(e.clientX); }}
          onMouseUp={() => (dragging.current = false)}
          onMouseLeave={() => (dragging.current = false)}
          onTouchMove={(e) => update(e.touches[0].clientX)}
          className="relative mt-10 aspect-[16/9] w-full overflow-hidden rounded-3xl glass-strong glow-border cursor-ew-resize select-none"
        >
          <img src={wsOriginal} alt="Original satellite watershed" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
            <img src={wsMask} alt="AI predicted watershed mask" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover" />
          </div>
          <div className="absolute top-0 bottom-0 z-10" style={{ left: `${pos}%`, transform: "translateX(-50%)" }}>
            <div className="h-full w-0.5 bg-gradient-to-b from-primary via-cyan to-violet glow-primary" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-12 w-12 rounded-full glass-strong flex items-center justify-center glow-primary">
              <ChevronRight className="h-4 w-4 -ml-1.5" />
              <ChevronRight className="h-4 w-4 -ml-2 rotate-180" />
            </div>
          </div>
          <div className="absolute top-4 left-4 glass rounded-full px-3 py-1 text-[10px] uppercase tracking-widest">Original</div>
          <div className="absolute top-4 right-4 glass rounded-full px-3 py-1 text-[10px] uppercase tracking-widest text-cyan">AI Mask</div>
        </div>
      </div>
    </section>
  );
}

function Workflow() {
  return (
    <section id="workflow" className="relative px-4 py-24">
      <div className="mx-auto max-w-7xl">
        <SectionTitle eyebrow="Pipeline" title="From orbit to insight in six stages" subtitle="A continuous neural pipeline orchestrating ingestion, inference, and visualization." />
        <div className="mt-14 relative">
          <div className="absolute left-0 right-0 top-7 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent hidden lg:block" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
            {workflow.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="relative"
              >
                <div className="relative mx-auto h-14 w-14 rounded-2xl glass-strong flex items-center justify-center glow-border">
                  <step.icon className="h-5 w-5 text-primary" />
                  <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-gradient-to-br from-primary to-violet text-[10px] font-bold text-primary-foreground flex items-center justify-center">
                    {i + 1}
                  </span>
                </div>
                <div className="mt-4 text-center">
                  <div className="font-display font-semibold text-sm">{step.title}</div>
                  <div className="text-xs text-muted-foreground mt-1">{step.desc}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Features() {
  return (
    <section id="features" className="relative px-4 py-24">
      <div className="mx-auto max-w-7xl">
        <SectionTitle eyebrow="Platform" title="Engineered for climate intelligence" subtitle="A modular geospatial AI stack purpose-built for hydrology and earth observation teams." />
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="group relative glass-strong glow-border rounded-3xl p-7 hover:-translate-y-1 transition-transform overflow-hidden"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${f.color} opacity-0 group-hover:opacity-100 transition-opacity`} />
              <div className="relative">
                <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-primary/20 to-violet/10 flex items-center justify-center">
                  <f.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="mt-5 font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="relative px-4 py-24">
      <div className="mx-auto max-w-5xl relative glass-strong glow-border rounded-[40px] p-10 lg:p-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/15 via-violet/10 to-transparent" />
        <Particles count={20} />
        <div className="relative text-center">
          <h2 className="font-display text-4xl lg:text-6xl font-bold tracking-tighter">
            Step into the <span className="text-gradient">command center</span>.
          </h2>
          <p className="mt-5 text-muted-foreground max-w-xl mx-auto">
            Launch HYDRA·AI's full geospatial console — interactive maps, live inference, and elegant analytics.
          </p>
          <Link
            to="/dashboard"
            className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-primary to-violet px-7 py-4 text-sm font-semibold text-primary-foreground glow-primary hover:scale-[1.03] transition"
          >
            Enter Dashboard <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="relative px-4 pb-10 pt-6">
      <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-border/40 pt-6 text-xs text-muted-foreground">
        <div>© 2026 HYDRA·AI Research. All rights reserved.</div>
        <div className="flex gap-5">
          <a href="#" className="hover:text-foreground">Documentation</a>
          <a href="#" className="hover:text-foreground">Research</a>
          <a href="#" className="hover:text-foreground">API</a>
        </div>
      </div>
    </footer>
  );
}

function SectionTitle({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return (
    <div className="max-w-2xl">
      <div className="text-[11px] uppercase tracking-[0.25em] text-primary">{eyebrow}</div>
      <h2 className="mt-3 font-display text-4xl lg:text-5xl font-bold tracking-tighter">{title}</h2>
      <p className="mt-4 text-muted-foreground">{subtitle}</p>
    </div>
  );
}

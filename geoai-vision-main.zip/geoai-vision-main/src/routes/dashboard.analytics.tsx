import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/dashboard/TopBar";
import {
  AreaChart, Area, ResponsiveContainer, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, Tooltip, Legend,
} from "recharts";
import { Search, Filter, ArrowUpRight } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/dashboard/analytics")({
  component: Analytics,
});

const radarData = [
  { metric: "Accuracy", v: 94 }, { metric: "Precision", v: 96 }, { metric: "Recall", v: 91 },
  { metric: "F1", v: 95 }, { metric: "IoU", v: 94 }, { metric: "Speed", v: 88 },
];
const pieData = [
  { name: "Forest Streams", v: 42, color: "oklch(0.78 0.15 200)" },
  { name: "Lakes", v: 28, color: "oklch(0.65 0.22 290)" },
  { name: "Floodplains", v: 18, color: "oklch(0.75 0.18 155)" },
  { name: "Wetlands", v: 12, color: "oklch(0.78 0.16 75)" },
];
const flood = Array.from({ length: 30 }, (_, i) => ({
  d: i, low: 20 + Math.random() * 10, med: 30 + Math.sin(i / 4) * 15 + Math.random() * 8, high: 10 + Math.cos(i / 5) * 8 + Math.random() * 5,
}));
const tableData = Array.from({ length: 12 }, (_, i) => ({
  id: `WS-${1000 + i}`,
  region: ["Brahmaputra", "Subansiri", "Lohit", "Dibang", "Siang"][i % 5],
  iou: (0.88 + Math.random() * 0.1).toFixed(3),
  area: Math.floor(200 + Math.random() * 1500),
  conf: (0.85 + Math.random() * 0.14).toFixed(2),
  status: ["Validated", "Processing", "Review"][i % 3],
}));

function Analytics() {
  const [q, setQ] = useState("");
  const filtered = tableData.filter((r) => r.region.toLowerCase().includes(q.toLowerCase()) || r.id.toLowerCase().includes(q.toLowerCase()));

  return (
    <>
      <TopBar title="Satellite Analytics" subtitle="Model performance & geospatial metrics" />
      <div className="flex-1 p-4 md:p-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card title="Model Performance" eyebrow="Radar" span={1}>
            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="oklch(1 0 0 / 0.1)" />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10, fill: "oklch(0.65 0.03 240)" }} />
                <Radar dataKey="v" stroke="oklch(0.78 0.15 200)" fill="oklch(0.78 0.15 200)" fillOpacity={0.3} />
              </RadarChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Watershed Composition" eyebrow="Distribution" span={1}>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={pieData} dataKey="v" innerRadius={60} outerRadius={100} paddingAngle={4}>
                  {pieData.map((e, i) => <Cell key={i} fill={e.color} stroke="transparent" />)}
                </Pie>
                <Tooltip contentStyle={{ background: "oklch(0.13 0.02 240)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 11 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Confidence Trend" eyebrow="7d" span={1}>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={Array.from({ length: 14 }, (_, i) => ({ d: i, v: 88 + Math.sin(i / 2) * 5 + Math.random() * 3 }))}>
                <XAxis dataKey="d" hide /><YAxis hide domain={[80, 100]} />
                <Tooltip contentStyle={{ background: "oklch(0.13 0.02 240)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 11 }} />
                <Line dataKey="v" stroke="oklch(0.65 0.22 290)" strokeWidth={2.5} dot={{ r: 3, fill: "oklch(0.78 0.15 200)" }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>

        <Card title="Flood Risk Forecast" eyebrow="30 day projection" span={3}>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={flood}>
              <defs>
                <linearGradient id="r-low" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="oklch(0.75 0.18 155)" stopOpacity={0.5} /><stop offset="100%" stopColor="oklch(0.75 0.18 155)" stopOpacity={0} /></linearGradient>
                <linearGradient id="r-med" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="oklch(0.78 0.16 75)" stopOpacity={0.5} /><stop offset="100%" stopColor="oklch(0.78 0.16 75)" stopOpacity={0} /></linearGradient>
                <linearGradient id="r-high" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="oklch(0.65 0.22 22)" stopOpacity={0.5} /><stop offset="100%" stopColor="oklch(0.65 0.22 22)" stopOpacity={0} /></linearGradient>
              </defs>
              <XAxis dataKey="d" tick={{ fontSize: 10, fill: "oklch(0.65 0.03 240)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "oklch(0.65 0.03 240)" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "oklch(0.13 0.02 240)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 11 }} />
              <Area dataKey="low" stackId="1" stroke="oklch(0.75 0.18 155)" fill="url(#r-low)" />
              <Area dataKey="med" stackId="1" stroke="oklch(0.78 0.16 75)" fill="url(#r-med)" />
              <Area dataKey="high" stackId="1" stroke="oklch(0.65 0.22 22)" fill="url(#r-high)" />
              <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <div className="glass-strong glow-border rounded-3xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-primary">Detection History</div>
              <h3 className="font-display text-lg font-semibold">Recent Watersheds</h3>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 glass rounded-xl px-3 py-1.5 w-56">
                <Search className="h-3.5 w-3.5 text-muted-foreground" />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search ID or region…" className="bg-transparent text-xs outline-none flex-1" />
              </div>
              <button className="glass rounded-xl p-2 hover:text-primary"><Filter className="h-4 w-4" /></button>
            </div>
          </div>
          <div className="overflow-x-auto rounded-2xl">
            <table className="w-full text-sm">
              <thead className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground sticky top-0">
                <tr className="border-b border-border/40">
                  <th className="text-left py-3 px-3 font-medium">ID</th>
                  <th className="text-left py-3 px-3 font-medium">Region</th>
                  <th className="text-right py-3 px-3 font-medium">IoU</th>
                  <th className="text-right py-3 px-3 font-medium">Area km²</th>
                  <th className="text-right py-3 px-3 font-medium">Conf</th>
                  <th className="text-left py-3 px-3 font-medium">Status</th>
                  <th className="py-3 px-3"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r, i) => (
                  <tr key={r.id} className="border-b border-border/20 hover:bg-white/[0.03] transition" style={{ animationDelay: `${i * 30}ms` }}>
                    <td className="py-3 px-3 font-mono text-xs text-primary">{r.id}</td>
                    <td className="py-3 px-3">{r.region}</td>
                    <td className="py-3 px-3 text-right font-mono text-xs">{r.iou}</td>
                    <td className="py-3 px-3 text-right font-mono text-xs">{r.area.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right font-mono text-xs text-cyan">{r.conf}</td>
                    <td className="py-3 px-3">
                      <span className={`text-[10px] px-2 py-0.5 rounded-md ${r.status === "Validated" ? "bg-success/15 text-success" : r.status === "Processing" ? "bg-warning/15 text-warning" : "bg-violet/15 text-violet"}`}>{r.status}</span>
                    </td>
                    <td className="py-3 px-3 text-right"><ArrowUpRight className="h-3.5 w-3.5 text-muted-foreground hover:text-primary inline" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
            <span>Showing {filtered.length} of {tableData.length}</span>
            <div className="flex gap-1">
              <button className="glass rounded-lg px-3 py-1">Prev</button>
              <button className="rounded-lg px-3 py-1 bg-primary text-primary-foreground">1</button>
              <button className="glass rounded-lg px-3 py-1">2</button>
              <button className="glass rounded-lg px-3 py-1">Next</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function Card({ title, eyebrow, children }: any) {
  return (
    <div className="glass-strong glow-border rounded-3xl p-5">
      <div className="mb-3">
        <div className="text-[10px] uppercase tracking-[0.2em] text-primary">{eyebrow}</div>
        <h3 className="font-display text-base font-semibold">{title}</h3>
      </div>
      {children}
    </div>
  );
}

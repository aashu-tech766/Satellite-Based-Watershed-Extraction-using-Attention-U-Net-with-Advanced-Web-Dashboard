import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/dashboard/TopBar";
import { motion } from "framer-motion";
import { useEffect, useState, useRef, MouseEvent } from "react";
import {
  AreaChart, Area, ResponsiveContainer, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, Tooltip, RadialBarChart, RadialBar, PolarAngleAxis,
} from "recharts";
import {
  Satellite, Activity, Cpu, Gauge, Upload, Layers, Eye, EyeOff,
  ZoomIn, ZoomOut, Crosshair, ChevronRight,
} from "lucide-react";
import { Particles } from "@/components/Particles";
import wsOriginal from "@/assets/watershed-original.jpg";
import wsMask from "@/assets/watershed-mask.jpg";

export const Route = createFileRoute("/dashboard/")({
  component: DashboardHome,
});

const trend = Array.from({ length: 24 }, (_, i) => ({
  t: i, accuracy: 88 + Math.sin(i / 2) * 4 + Math.random() * 2, conf: 80 + Math.cos(i / 3) * 6 + Math.random() * 3,
}));

const metrics = [
  { label: "Mean IoU", value: 94.7, suffix: "%", trend: "+2.3", icon: Gauge, color: "from-primary to-cyan" },
  { label: "Precision", value: 96.2, suffix: "%", trend: "+0.8", icon: Activity, color: "from-violet to-primary" },
  { label: "F1 Score", value: 0.951, suffix: "", trend: "+0.012", icon: Cpu, color: "from-success to-cyan" },
  { label: "GPU Usage", value: 67, suffix: "%", trend: "stable", icon: Cpu, color: "from-warning to-primary" },
];

function DashboardHome() {
  return (
    <>
      <TopBar title="Command Center" subtitle="Real-time geospatial intelligence" />
      <div className="flex-1 p-4 md:p-6 space-y-6">
        <Hero />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((m, i) => <MetricCard key={m.label} {...m} delay={i * 0.05} />)}
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <UploadPanel />
          <MapPanel />
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <SegmentationViewer />
          <ActivityTerminal />
        </div>
        <ChartsRow />
      </div>
    </>
  );
}

function Hero() {
  return (
    <div className="relative overflow-hidden rounded-3xl glass-strong glow-border p-6 md:p-8">
      <Particles count={20} />
      <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="text-[11px] uppercase tracking-[0.25em] text-primary">Mission · WS-2026.05</div>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold tracking-tight">
            Welcome back, <span className="text-gradient">Aria</span>
          </h2>
          <p className="mt-2 text-sm text-muted-foreground max-w-md">
            Your Attention U-Net pipeline processed <span className="text-foreground font-medium">2,148 tiles</span> overnight across the Brahmaputra basin.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary to-violet px-4 py-2.5 text-xs font-semibold text-primary-foreground glow-primary hover:scale-[1.02] transition">
            <Satellite className="h-3.5 w-3.5" /> New Inference Run
          </button>
          <button className="inline-flex items-center gap-2 rounded-xl glass px-4 py-2.5 text-xs font-semibold hover:bg-white/[0.06]">
            View Last Report <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ label, value, suffix, trend, icon: Icon, color, delay }: any) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf = 0; const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / 1200, 1);
      setV(value * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay }}
      className="group relative glass-strong glow-border rounded-2xl p-5 overflow-hidden hover:-translate-y-1 transition-transform"
    >
      <div className={`absolute -top-10 -right-10 h-32 w-32 rounded-full bg-gradient-to-br ${color} opacity-20 blur-2xl group-hover:opacity-40 transition`} />
      <div className="relative">
        <div className="flex items-center justify-between">
          <Icon className="h-4 w-4 text-primary" />
          <span className="text-[10px] text-success font-medium">{trend}</span>
        </div>
        <div className="mt-3 font-display text-3xl font-bold tracking-tight">
          {suffix === "%" ? v.toFixed(1) : v.toFixed(3)}<span className="text-base text-muted-foreground">{suffix}</span>
        </div>
        <div className="mt-1 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
        <div className="mt-3 h-8 -mx-1">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trend.length ? Array.from({ length: 12 }, (_, i) => ({ v: 50 + Math.sin(i + label.length) * 20 + Math.random() * 10 })) : []}>
              <defs>
                <linearGradient id={`g-${label}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="oklch(0.78 0.15 200)" stopOpacity={0.6} />
                  <stop offset="100%" stopColor="oklch(0.78 0.15 200)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area dataKey="v" stroke="oklch(0.78 0.15 200)" strokeWidth={1.5} fill={`url(#g-${label})`} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </motion.div>
  );
}

function UploadPanel() {
  const [drag, setDrag] = useState(false);
  const [progress, setProgress] = useState(0);
  const [file, setFile] = useState<string | null>(null);

  const startUpload = (name: string) => {
    setFile(name); setProgress(0);
    const id = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) { clearInterval(id); return 100; }
        return p + 4;
      });
    }, 80);
  };

  return (
    <div className="glass-strong glow-border rounded-3xl p-5 xl:col-span-1">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-primary">Ingest</div>
          <h3 className="font-display text-lg font-semibold">Satellite Upload</h3>
        </div>
        <Upload className="h-4 w-4 text-muted-foreground" />
      </div>
      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); startUpload(e.dataTransfer.files[0]?.name || "tile.tif"); }}
        onClick={() => startUpload("S2A_T43QFV_20260514.tif")}
        className={`relative cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition ${drag ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}`}
      >
        {drag && <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/10 to-violet/10 animate-pulse-glow" />}
        <div className="relative">
          <div className="mx-auto h-12 w-12 rounded-2xl bg-gradient-to-br from-primary/20 to-violet/10 flex items-center justify-center">
            <Upload className="h-5 w-5 text-primary" />
          </div>
          <div className="mt-4 font-display font-semibold text-sm">Drop GeoTIFF tiles</div>
          <div className="mt-1 text-xs text-muted-foreground">or click to browse · max 5GB</div>
          <div className="mt-3 flex flex-wrap justify-center gap-1.5">
            {["TIFF", "JP2", "HDF", "NETCDF"].map((f) => (
              <span key={f} className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-muted-foreground">{f}</span>
            ))}
          </div>
        </div>
      </div>

      {file && (
        <div className="mt-4 rounded-xl glass p-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-mono truncate">{file}</span>
            <span className="text-primary">{progress}%</span>
          </div>
          <div className="mt-2 h-1 rounded-full bg-white/5 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-primary to-violet transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}
    </div>
  );
}

function MapPanel() {
  const [layers, setLayers] = useState({ satellite: true, watershed: true, rivers: true, heatmap: false });
  const [hover, setHover] = useState<{ x: number; y: number; name: string } | null>(null);

  const regions = [
    { x: 30, y: 35, name: "Brahmaputra Sub-Basin · 1,284 km²" },
    { x: 60, y: 50, name: "Subansiri · 842 km²" },
    { x: 45, y: 70, name: "Lohit · 567 km²" },
  ];

  return (
    <div className="glass-strong glow-border rounded-3xl p-5 xl:col-span-2 relative overflow-hidden">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-primary">Geospatial</div>
          <h3 className="font-display text-lg font-semibold">Live Watershed Map</h3>
        </div>
        <div className="flex items-center gap-1.5">
          <button className="glass rounded-lg p-1.5 hover:text-primary"><ZoomIn className="h-3.5 w-3.5" /></button>
          <button className="glass rounded-lg p-1.5 hover:text-primary"><ZoomOut className="h-3.5 w-3.5" /></button>
          <button className="glass rounded-lg p-1.5 hover:text-primary"><Crosshair className="h-3.5 w-3.5" /></button>
        </div>
      </div>

      <div className="relative h-[360px] rounded-2xl overflow-hidden glow-border">
        <img src={wsOriginal} alt="map" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover" />
        {layers.watershed && (
          <img src={wsMask} alt="mask" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover mix-blend-screen opacity-70" />
        )}
        {layers.heatmap && <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,oklch(0.7_0.2_22/0.4),transparent_40%),radial-gradient(circle_at_70%_60%,oklch(0.78_0.16_75/0.35),transparent_40%)]" />}
        <div className="absolute inset-0 grid-bg opacity-30" />

        {regions.map((r) => (
          <button
            key={r.name}
            onMouseEnter={() => setHover(r)}
            onMouseLeave={() => setHover(null)}
            className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${r.x}%`, top: `${r.y}%` }}
          >
            <span className="absolute inset-0 rounded-full bg-cyan animate-pulse-glow" />
            <span className="absolute -inset-2 rounded-full border border-cyan/40" />
          </button>
        ))}

        {hover && (
          <div className="absolute glass-strong rounded-xl px-3 py-2 text-xs pointer-events-none" style={{ left: `${hover.x}%`, top: `${hover.y - 10}%`, transform: "translate(-50%, -100%)" }}>
            {hover.name}
          </div>
        )}

        <div className="absolute bottom-3 left-3 glass rounded-xl p-2 space-y-1">
          {Object.entries(layers).map(([k, v]) => (
            <button
              key={k}
              onClick={() => setLayers((s) => ({ ...s, [k]: !v }))}
              className="flex items-center gap-2 text-[11px] capitalize w-full px-2 py-1 rounded hover:bg-white/5"
            >
              {v ? <Eye className="h-3 w-3 text-primary" /> : <EyeOff className="h-3 w-3 text-muted-foreground" />}
              <Layers className="h-3 w-3 text-muted-foreground" />
              {k}
            </button>
          ))}
        </div>

        <div className="absolute top-3 right-3 glass rounded-xl px-3 py-1.5 text-[10px] uppercase tracking-widest">
          Lat 27.4° N · Lon 94.2° E
        </div>
      </div>
    </div>
  );
}

function SegmentationViewer() {
  const [pos, setPos] = useState(50);
  const ref = useRef<HTMLDivElement>(null);
  const drag = useRef(false);
  const update = (x: number) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    setPos(Math.max(0, Math.min(100, ((x - r.left) / r.width) * 100)));
  };

  return (
    <div className="glass-strong glow-border rounded-3xl p-5 xl:col-span-2">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-primary">Inference</div>
          <h3 className="font-display text-lg font-semibold">U-Net Segmentation Viewer</h3>
        </div>
        <div className="text-[11px] text-muted-foreground">Tile · S2A_T43QFV · 2026-05-14</div>
      </div>
      <div
        ref={ref}
        onMouseDown={(e: MouseEvent) => { drag.current = true; update(e.clientX); }}
        onMouseUp={() => (drag.current = false)}
        onMouseLeave={() => (drag.current = false)}
        onMouseMove={(e: MouseEvent) => drag.current && update(e.clientX)}
        className="relative aspect-video rounded-2xl overflow-hidden cursor-ew-resize glow-border"
      >
        <img src={wsOriginal} alt="orig" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
          <img src={wsMask} alt="mask" loading="lazy" width={1024} height={1024} className="absolute inset-0 h-full w-full object-cover" />
        </div>
        <div className="absolute top-0 bottom-0 z-10" style={{ left: `${pos}%`, transform: "translateX(-50%)" }}>
          <div className="h-full w-0.5 bg-gradient-to-b from-primary via-cyan to-violet glow-primary" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-10 w-10 rounded-full glass-strong flex items-center justify-center glow-primary">
            <ChevronRight className="h-3.5 w-3.5 -ml-1" />
            <ChevronRight className="h-3.5 w-3.5 -ml-2 rotate-180" />
          </div>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-3 text-xs">
        {[{ l: "Confidence", v: "0.96" }, { l: "Pixels Detected", v: "1.2M" }, { l: "Inference", v: "1.8s" }].map((x) => (
          <div key={x.l} className="glass rounded-xl p-3">
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{x.l}</div>
            <div className="mt-1 font-display text-lg font-bold text-gradient-cyan">{x.v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActivityTerminal() {
  const [lines, setLines] = useState<string[]>([]);
  const seed = [
    "[INIT] CUDA stream allocated · A100 80GB",
    "[LOAD] attn_unet_v4.2.pt → 184MB",
    "[INF] tile S2A_T43QFV → mask 1024×1024",
    "[OK]  IoU=0.947 · prec=0.962 · rec=0.941",
    "[GIS] vector tiles emitted · z=12",
    "[INF] tile S2A_T44QFA → mask 1024×1024",
    "[OK]  IoU=0.952 · conf=0.96",
    "[BG]  watershed delineation · 1284 km²",
  ];
  useEffect(() => {
    let i = 0;
    const id = setInterval(() => {
      setLines((l) => [...l.slice(-12), seed[i % seed.length]]);
      i++;
    }, 1200);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="glass-strong glow-border rounded-3xl p-5 xl:col-span-1">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-primary">Live</div>
          <h3 className="font-display text-lg font-semibold">AI Activity</h3>
        </div>
        <span className="h-2 w-2 rounded-full bg-success animate-pulse-glow" />
      </div>
      <div className="rounded-2xl bg-black/40 border border-border/50 p-3 font-mono text-[11px] h-[280px] overflow-hidden relative">
        <div className="space-y-1">
          {lines.map((l, i) => (
            <div key={i} className="text-cyan/90">
              <span className="text-muted-foreground">› </span>{l}
            </div>
          ))}
          <div className="text-cyan flex items-center"><span className="text-muted-foreground">› </span>processing<span className="animate-blink ml-0.5">▌</span></div>
        </div>
      </div>
    </div>
  );
}

function ChartsRow() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <ChartCard title="Accuracy Trend" eyebrow="24h">
        <ResponsiveContainer width="100%" height={180}>
          <LineChart data={trend}>
            <defs>
              <linearGradient id="lc" x1="0" x2="1"><stop offset="0%" stopColor="oklch(0.78 0.15 200)" /><stop offset="100%" stopColor="oklch(0.65 0.22 290)" /></linearGradient>
            </defs>
            <XAxis dataKey="t" hide /><YAxis hide domain={[80, 100]} />
            <Tooltip contentStyle={{ background: "oklch(0.13 0.02 240)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 11 }} />
            <Line dataKey="accuracy" stroke="url(#lc)" strokeWidth={2.5} dot={false} />
            <Line dataKey="conf" stroke="oklch(0.65 0.22 290)" strokeWidth={1.5} dot={false} strokeDasharray="3 3" />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Watershed Coverage" eyebrow="By Region">
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={[{ n: "Brahma", v: 1284 }, { n: "Subansiri", v: 842 }, { n: "Lohit", v: 567 }, { n: "Dibang", v: 491 }, { n: "Siang", v: 388 }]}>
            <XAxis dataKey="n" tick={{ fontSize: 10, fill: "oklch(0.65 0.03 240)" }} axisLine={false} tickLine={false} />
            <YAxis hide />
            <Tooltip contentStyle={{ background: "oklch(0.13 0.02 240)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 11 }} />
            <Bar dataKey="v" fill="oklch(0.78 0.15 200)" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Model Health" eyebrow="Realtime">
        <ResponsiveContainer width="100%" height={180}>
          <RadialBarChart innerRadius="40%" outerRadius="100%" data={[
            { n: "IoU", v: 94, fill: "oklch(0.78 0.15 200)" },
            { n: "Prec", v: 96, fill: "oklch(0.65 0.22 290)" },
            { n: "Rec", v: 91, fill: "oklch(0.75 0.18 155)" },
          ]} startAngle={90} endAngle={-270}>
            <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
            <RadialBar background dataKey="v" cornerRadius={20} />
          </RadialBarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

function ChartCard({ title, eyebrow, children }: any) {
  return (
    <div className="glass-strong glow-border rounded-3xl p-5">
      <div className="flex items-center justify-between mb-2">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-primary">{eyebrow}</div>
          <h3 className="font-display text-base font-semibold">{title}</h3>
        </div>
      </div>
      {children}
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/dashboard/TopBar";
import { FileText, Download, FileImage, FileJson, FileBarChart, Calendar, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/dashboard/reports")({
  component: Reports,
});

const reports = [
  { title: "Brahmaputra Basin · Q1 Climate Report", type: "PDF", size: "12.4 MB", date: "May 12, 2026", icon: FileText, accent: "from-primary/30 to-cyan/10" },
  { title: "Watershed Mask Vectors · GeoJSON Pack", type: "JSON", size: "48.2 MB", date: "May 11, 2026", icon: FileJson, accent: "from-violet/30 to-primary/10" },
  { title: "Flood Risk Heatmap · 30-day", type: "PNG", size: "6.8 MB", date: "May 10, 2026", icon: FileImage, accent: "from-success/30 to-cyan/10" },
  { title: "Model Benchmark Summary", type: "PDF", size: "3.1 MB", date: "May 09, 2026", icon: FileBarChart, accent: "from-warning/30 to-primary/10" },
  { title: "Subansiri Sub-basin Inventory", type: "CSV", size: "1.2 MB", date: "May 08, 2026", icon: FileText, accent: "from-violet/30 to-cyan/10" },
  { title: "AI Confidence Audit · Research", type: "PDF", size: "8.7 MB", date: "May 06, 2026", icon: FileText, accent: "from-primary/30 to-violet/10" },
];

function Reports() {
  return (
    <>
      <TopBar title="Report Generation" subtitle="Export geospatial intelligence" />
      <div className="flex-1 p-4 md:p-6 space-y-6">
        <div className="relative overflow-hidden rounded-3xl glass-strong glow-border p-7">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/15 via-violet/10 to-transparent" />
          <div className="relative flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
            <div>
              <div className="text-[10px] uppercase tracking-[0.25em] text-primary">Generate</div>
              <h2 className="mt-2 font-display text-3xl font-bold">New Intelligence Report</h2>
              <p className="mt-2 text-sm text-muted-foreground max-w-md">
                Compose a multi-page report combining masks, analytics, and research summaries.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {["PDF Report", "GIS Bundle", "Research Brief"].map((t) => (
                <button key={t} className="glass rounded-xl px-4 py-2.5 text-xs font-semibold hover:bg-white/[0.06]">{t}</button>
              ))}
              <button className="rounded-xl bg-gradient-to-r from-primary to-violet px-5 py-2.5 text-xs font-semibold text-primary-foreground glow-primary inline-flex items-center gap-1.5">
                Generate <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-xl font-semibold">Recent Exports</h3>
            <div className="text-xs text-muted-foreground flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" /> Last 30 days</div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {reports.map((r) => (
              <div key={r.title} className="group relative glass-strong glow-border rounded-3xl p-5 overflow-hidden hover:-translate-y-1 transition-transform">
                <div className={`absolute -top-12 -right-12 h-40 w-40 rounded-full bg-gradient-to-br ${r.accent} opacity-30 blur-2xl group-hover:opacity-60 transition`} />
                <div className="relative">
                  <div className="flex items-start justify-between">
                    <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-primary/20 to-violet/10 flex items-center justify-center">
                      <r.icon className="h-5 w-5 text-primary" />
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-muted-foreground font-mono">{r.type}</span>
                  </div>
                  <h4 className="mt-4 font-display font-semibold leading-snug">{r.title}</h4>
                  <div className="mt-3 flex items-center justify-between text-[11px] text-muted-foreground">
                    <span>{r.date}</span><span>{r.size}</span>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <button className="flex-1 glass rounded-xl py-2 text-xs font-semibold hover:bg-white/[0.06]">Preview</button>
                    <button className="rounded-xl bg-gradient-to-r from-primary to-violet px-4 py-2 text-xs font-semibold text-primary-foreground glow-primary inline-flex items-center gap-1.5">
                      <Download className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

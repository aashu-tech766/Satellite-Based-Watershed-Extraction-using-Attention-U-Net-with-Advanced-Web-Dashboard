import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/dashboard/TopBar";
import { useState } from "react";
import { Brain, Cpu, Save, Zap, Activity } from "lucide-react";

export const Route = createFileRoute("/dashboard/settings")({
  component: Settings,
});

function Settings() {
  const [conf, setConf] = useState(0.85);
  const [lr, setLr] = useState(0.0003);
  const [batch, setBatch] = useState(16);
  const [toggles, setToggles] = useState({ mixedPrecision: true, attentionGates: true, autoSave: false, realTimeInf: true });

  return (
    <>
      <TopBar title="AI Settings" subtitle="Attention U-Net control center" />
      <div className="flex-1 p-4 md:p-6 grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 space-y-4">
          <Card title="Inference Parameters" eyebrow="Runtime" icon={Brain}>
            <div className="space-y-6">
              <Slider label="Confidence Threshold" value={conf} onChange={setConf} min={0} max={1} step={0.01} format={(v: number) => v.toFixed(2)} />
              <Slider label="Learning Rate" value={lr} onChange={setLr} min={0.00001} max={0.001} step={0.00001} format={(v: number) => v.toExponential(2)} />
              <Slider label="Batch Size" value={batch} onChange={setBatch} min={1} max={64} step={1} format={(v: number) => String(v)} />
            </div>
          </Card>

          <Card title="Model Toggles" eyebrow="Architecture" icon={Cpu}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.entries(toggles).map(([k, v]) => (
                <button
                  key={k}
                  onClick={() => setToggles((s) => ({ ...s, [k]: !v }))}
                  className="glass rounded-2xl p-4 flex items-center justify-between hover:bg-white/[0.05] transition"
                >
                  <div className="text-left">
                    <div className="text-sm font-medium capitalize">{k.replace(/([A-Z])/g, " $1")}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{v ? "Enabled" : "Disabled"}</div>
                  </div>
                  <Toggle on={v} />
                </button>
              ))}
            </div>
          </Card>

          <Card title="Training Progress" eyebrow="Epoch 47/100" icon={Activity}>
            <div className="space-y-4">
              {[
                { l: "Loss", v: 0.038, w: "76%" },
                { l: "Validation IoU", v: 0.947, w: "94%" },
                { l: "GPU Utilization", v: "67%", w: "67%" },
              ].map((m) => (
                <div key={m.l}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-muted-foreground">{m.l}</span>
                    <span className="font-mono text-cyan">{m.v}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/5 overflow-hidden relative">
                    <div className="h-full bg-gradient-to-r from-primary to-violet glow-primary" style={{ width: m.w }} />
                    <div className="absolute inset-y-0 -inset-x-1 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer" />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Hardware" eyebrow="Compute" icon={Zap}>
            <div className="space-y-3 text-sm">
              {[
                { l: "GPU", v: "NVIDIA A100 80GB" },
                { l: "VRAM", v: "54.1 / 80 GB" },
                { l: "CPU Threads", v: "32" },
                { l: "Region", v: "us-east-1" },
              ].map((r) => (
                <div key={r.l} className="flex justify-between py-2 border-b border-border/30 last:border-0">
                  <span className="text-muted-foreground">{r.l}</span>
                  <span className="font-mono text-xs">{r.v}</span>
                </div>
              ))}
            </div>
          </Card>

          <div className="glass-strong glow-border rounded-3xl p-5 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/15 via-violet/10 to-transparent" />
            <div className="relative">
              <div className="text-[10px] uppercase tracking-[0.2em] text-primary">Apply Changes</div>
              <h3 className="mt-2 font-display text-xl font-semibold">Sync to Cluster</h3>
              <p className="mt-1 text-xs text-muted-foreground">Push the new configuration to the live inference fleet.</p>
              <button className="mt-4 w-full rounded-xl bg-gradient-to-r from-primary to-violet py-3 text-xs font-semibold text-primary-foreground glow-primary inline-flex items-center justify-center gap-2 hover:scale-[1.02] transition">
                <Save className="h-3.5 w-3.5" /> Save Configuration
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function Card({ title, eyebrow, icon: Icon, children }: any) {
  return (
    <div className="glass-strong glow-border rounded-3xl p-5">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-primary">{eyebrow}</div>
          <h3 className="font-display text-lg font-semibold">{title}</h3>
        </div>
        <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-primary/20 to-violet/10 flex items-center justify-center">
          <Icon className="h-4 w-4 text-primary" />
        </div>
      </div>
      {children}
    </div>
  );
}

function Slider({ label, value, onChange, min, max, step, format }: any) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="flex justify-between text-xs mb-2">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono text-cyan">{format(value)}</span>
      </div>
      <div className="relative h-2 rounded-full bg-white/5">
        <div className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-primary to-violet glow-primary" style={{ width: `${pct}%` }} />
        <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))}
          className="absolute inset-0 w-full opacity-0 cursor-pointer" />
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 h-4 w-4 rounded-full bg-white glow-primary pointer-events-none" style={{ left: `${pct}%` }} />
      </div>
    </div>
  );
}

function Toggle({ on }: { on: boolean }) {
  return (
    <span className={`relative inline-flex h-6 w-11 rounded-full transition ${on ? "bg-gradient-to-r from-primary to-violet glow-primary" : "bg-white/10"}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${on ? "translate-x-5" : "translate-x-0.5"}`} />
    </span>
  );
}

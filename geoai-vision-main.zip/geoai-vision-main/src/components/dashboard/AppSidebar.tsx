import { Link, useRouterState } from "@tanstack/react-router";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  SidebarHeader, SidebarFooter, useSidebar,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard, Satellite, Waves, BarChart3, FileText, Settings, Sparkles, Activity,
} from "lucide-react";

const nav = [
  { title: "Command Center", url: "/dashboard", icon: LayoutDashboard },
  { title: "Satellite Analytics", url: "/dashboard/analytics", icon: Satellite },
  { title: "Watershed Studio", url: "/dashboard/watershed", icon: Waves },
  { title: "Reports", url: "/dashboard/reports", icon: FileText },
  { title: "AI Settings", url: "/dashboard/settings", icon: Settings },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const path = useRouterState({ select: (r) => r.location.pathname });

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarHeader className="border-b border-sidebar-border/60 py-4">
        <Link to="/" className="flex items-center gap-2.5 px-2">
          <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-violet glow-primary">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="font-display text-sm font-bold tracking-tight">HYDRA·AI</span>
              <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Geospatial OS</span>
            </div>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent className="px-2">
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground/70">
            Workspace
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {nav.map((item) => {
                const active = path === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={active}
                      className="group relative h-10 rounded-xl data-[active=true]:bg-gradient-to-r data-[active=true]:from-primary/15 data-[active=true]:to-violet/10 data-[active=true]:text-foreground"
                    >
                      <Link to={item.url} className="flex items-center gap-3">
                        <item.icon className={`h-4 w-4 transition-colors ${active ? "text-primary" : ""}`} />
                        {!collapsed && <span className="text-sm">{item.title}</span>}
                        {active && (
                          <span className="absolute right-2 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-primary animate-pulse-glow" />
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {!collapsed && (
          <div className="mt-6 mx-2 rounded-2xl glass p-4 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-violet/10" />
            <div className="relative">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Activity className="h-3 w-3 text-success" />
                <span>AI Engine</span>
              </div>
              <div className="mt-2 font-display text-lg font-semibold">Online</div>
              <div className="mt-1 text-[11px] text-muted-foreground">U-Net v4.2 · GPU A100</div>
              <div className="mt-3 h-1 w-full rounded-full bg-white/5 overflow-hidden">
                <div className="h-full w-3/4 bg-gradient-to-r from-primary to-violet animate-pulse-glow" />
              </div>
            </div>
          </div>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border/60 p-3">
        {!collapsed ? (
          <div className="flex items-center gap-2.5 rounded-xl px-2 py-1.5">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-violet to-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
              AS
            </div>
            <div className="leading-tight">
              <div className="text-xs font-medium">Dr. Aria Sato</div>
              <div className="text-[10px] text-muted-foreground">Lead Hydrologist</div>
            </div>
          </div>
        ) : (
          <div className="mx-auto h-8 w-8 rounded-full bg-gradient-to-br from-violet to-primary" />
        )}
      </SidebarFooter>
    </Sidebar>
  );
}

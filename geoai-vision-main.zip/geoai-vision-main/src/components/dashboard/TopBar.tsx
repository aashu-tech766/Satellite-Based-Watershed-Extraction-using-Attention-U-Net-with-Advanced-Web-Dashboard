import { SidebarTrigger } from "@/components/ui/sidebar";
import { Bell, Search, Moon } from "lucide-react";

export function TopBar({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b border-border/60 bg-background/60 px-4 backdrop-blur-xl md:px-6">
      <SidebarTrigger className="text-muted-foreground hover:text-foreground" />
      <div className="hidden sm:block">
        <h1 className="font-display text-base font-semibold leading-tight">{title}</h1>
        {subtitle && <p className="text-[11px] text-muted-foreground">{subtitle}</p>}
      </div>

      <div className="ml-auto flex items-center gap-2">
        <div className="hidden md:flex items-center gap-2 glass rounded-xl px-3 py-1.5 w-72">
          <Search className="h-3.5 w-3.5 text-muted-foreground" />
          <input
            placeholder="Search regions, datasets, models…"
            className="bg-transparent text-xs outline-none flex-1 placeholder:text-muted-foreground/60"
          />
          <kbd className="text-[10px] text-muted-foreground border border-border rounded px-1.5 py-0.5">⌘K</kbd>
        </div>

        <div className="flex items-center gap-2 glass rounded-xl px-3 py-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse-glow" />
          <span className="text-[11px] text-muted-foreground">AI Online</span>
        </div>

        <button className="glass rounded-xl p-2 hover:text-primary transition-colors relative">
          <Bell className="h-4 w-4" />
          <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-primary animate-pulse-glow" />
        </button>
        <button className="glass rounded-xl p-2 hover:text-primary transition-colors">
          <Moon className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}

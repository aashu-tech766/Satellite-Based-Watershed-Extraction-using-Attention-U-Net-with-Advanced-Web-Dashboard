export function MeshBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40" />
      <div className="absolute -top-40 -left-40 h-[500px] w-[500px] rounded-full bg-primary/20 blur-[120px] animate-float" />
      <div
        className="absolute top-1/3 -right-32 h-[600px] w-[600px] rounded-full bg-violet/20 blur-[140px] animate-float"
        style={{ animationDelay: "3s" }}
      />
      <div
        className="absolute -bottom-40 left-1/4 h-[500px] w-[500px] rounded-full bg-cyan/15 blur-[120px] animate-float"
        style={{ animationDelay: "6s" }}
      />
    </div>
  );
}
